/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workingdays;

/**
 *
 * @author ABC
 */
 class addLocations {
    private String day,sTime,eTime;
    private int room;
   
    
    
    
   public addLocations(String semID,int dayNo,String wDays,String wTPerDay,String tSlot){
       this.room = room; 
       
        this.day = day;
        this.sTime = sTime;
        this.eTime=eTime;
        
    }
    
      
     
     public int room(){
        return room;
    }
     
     
     public String day(){
        return day;
    }
     
     
     
     
     public String sTime(){
        return sTime;
    }
     
     public String eTime(){
        return eTime;
    }

    

 
 
 }
