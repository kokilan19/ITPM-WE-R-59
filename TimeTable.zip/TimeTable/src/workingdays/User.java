/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workingdays;

/**
 *
 * @author ABC
 */
 class User {
    private String semID,wDays,wTPerDay,tSlot;
    private int dayNo;
    
    
    
    
   public User(String semID,int dayNo,String wDays,String wTPerDay,String tSlot){
       this.semID = semID; 
       
        this.dayNo = dayNo;
        this.wDays = wDays;
        this.wTPerDay = wTPerDay;
        this.tSlot=tSlot;
        
    }
    
      public String getsemID(){
        return semID;
    }
     
     public int dayNo(){
        return dayNo;
    }
     
     
     public String wDays(){
        return wDays;
    }
     
     
     
     
     public String wTPerDay(){
        return wTPerDay;
    }
     
     public String tSlot(){
        return tSlot;
    }

    Object getdayNo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getwDays() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getwTPerDay() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object gettSlot() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
 
 }
