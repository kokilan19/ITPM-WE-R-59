/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workingdays;

/**
 *
 * @author ABC
 */

 class Session {
    private String lecturer,group,subGroup,sessionId,time;
    private int semId;
    
   
    
    
    
   public Session(int semId,String lecturer,String group,String subGroup,String sessionId,String time){
      this.semId = semId; 
       
        this.lecturer = lecturer;
        this.group = group;
        this.subGroup=subGroup;
        this.sessionId=sessionId;
        this.time=time;
         
    }
    
      
     
     public int semId(){
        return semId;
    }
     
     
     public String lecturer(){
        return lecturer;
    }
     
     
     
     
     public String group(){
        return group;
    }
     
     public String subGroup(){
        return subGroup;
    }
    public String sessionId(){
        return sessionId;
    }
    
    public String time(){
        return time;
    }

    Object getsemId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getlecturer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getgroup() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getsubGroup() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getsessionId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object gettime() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
 
 }
