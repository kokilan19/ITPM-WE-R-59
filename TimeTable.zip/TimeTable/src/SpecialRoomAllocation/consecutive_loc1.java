/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpecialRoomAllocation;

/**
 *
 * @author User
 */
public class consecutive_loc1 {
      private int ConID;
    private String room;
    
    
    public consecutive_loc1(int ConID , String room){
        this.ConID = ConID;
        this.room = room;
    }
    
    public int getConID(){
        return ConID;
    }
    
     
    
    public String getroom() {
        return room;
    }
    
}
