/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modals;

/**
 *
 * @author vivekjeevanarajh
 */
public class Lecture_modal {
    private String emp_name;
    private String emp_id;
    private String acultry;
    private String department;
    private String center;
    private String building;
    private String add_level;
    private String rank;

    
    
    public Lecture_modal(String emp_name, String emp_id, String acultry, String department, String center, String building, String add_level, String rank) {
        this.emp_name = emp_name;
        this.emp_id = emp_id;
        this.acultry = acultry;
        this.department = department;
        this.center = center;
        this.building = building;
        this.add_level = add_level;
        this.rank = rank;
    }
    
    
            
  
}
