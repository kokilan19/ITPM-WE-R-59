# TimeTable
SPM module timetable management system. Tech : java swing, SQLite
Database  : tms.sqlite
